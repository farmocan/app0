
look_tab1 <- function(dat){ #, MYNAMES
datatable(dat,
          plugins = "ellipsis", rownames=F,#  autoWidth = TRUE,
          #colnames = MYNAMES, 
          options = list(dom = 't', ordering=F, pageLength = nrow(dat),autoWidth = TRUE,
                         columnDefs = list(
                           list(targets = 0:2,  className = "dt-head-left", render = JS("$.fn.dataTable.render.ellipsis(35, false )")),
                           #list(targets = 3:6, render = JS("$.fn.dataTable.render.ellipsis(2, false )")),
                           #list(targets = 7, render = JS("$.fn.dataTable.render.ellipsis(8, false )")),
                           #list(targets = 8:9, render = JS("$.fn.dataTable.render.ellipsis(2, false )")),
                           #list(targets = 10, render = JS("$.fn.dataTable.render.ellipsis(6, false )")),
                           #list(targets = 11:12, render = JS("$.fn.dataTable.render.ellipsis(6, false )")),
                           list(targets = 13, render = JS("$.fn.dataTable.render.ellipsis(45, false )"))
                           )
                         )
)
}

#newnames <- c("cname",	"bid", "c", "m", "l", "y", "x", "qid", "#v", "#t",  "time", "num", "den", "q_text")
#newnames %>% data.frame()

#look_tab1(coursera_data[1:30,], newnames)
