#heat map
#vers problem

#data
#one_course_data <- read.csv2("data\\subdata.csv", stringsAsFactors = F)
#one_course_data$cname %>% unique()

get_hm <- function(mydata){
  
  #mydata <- one_course_data
  #require(plotly)
  name_title <- mydata$cname %>% unique()
  
  
  
  mydata$tot_num <- as.numeric(as.character(mydata$tot_num))
  mydata$p <- mydata$tot_num / mydata$cnt
  
  wraptext <- sapply(mydata$text, function(str1){
    paste0(strwrap(substr(str1, 1, 600), width = 80), collapse = "\n")
  }) %>% as.character()
  
  mydata$info <- paste0("текст: ", wraptext, "\nn = ", mydata$cnt,
                        "\np = ", round(mydata$p, 2), "\n\nposit = ", mydata$m_ord, "|", mydata$l_ord,
                        "\nchanged text = ", mydata$UNIQUEtext#, "\n#ver = ", mydata$question_ext_id,
                        #"\nlast time = ", mydata$update_ts
  )
  
  
  
  #axis label
  my_y_week_VECTOR <- mydata$y_pos %>% unique()
  
  #X
  my_x_week_VECTOR <- mydata$x_pos %>% unique()
  
  for_yscale <- list(tickvals =my_y_week_VECTOR, ticktext = my_y_week_VECTOR,   autorange = "reversed") #fixedrange=TRUE ,
  
  
  for_xscale <- list(tickvals = my_x_week_VECTOR, ticktext = my_x_week_VECTOR,  fixedrange=TRUE)
  
  
  #create plot
 
  if(any(mydata$UNIQUEtext >1) == T){
    hm <- plot_ly(mydata) %>% 
      add_trace(
        type = "heatmap",
        x = ~x_pos, y = ~y_pos, z = ~p, xgap=2, ygap=2,
        text = ~info,
        hoverinfo='text',
        showscale = T
      )  %>% add_annotations(
        x = mydata$x_pos[mydata$UNIQUEtext >1], y = mydata$y_pos[mydata$UNIQUEtext >1],
        text = mydata$UNIQUEtext[mydata$UNIQUEtext >1],
        bgcolor="#ff7f0e",
        opacity=0.8,
        align="left", showarrow = FALSE, ax = 0, ay = 0
      )
  } else {
    hm <- plot_ly(mydata) %>% 
      add_trace(
        type = "heatmap",
        x = ~x_pos, y = ~y_pos, z = ~p, xgap=2, ygap=2,
        text = ~info,
        hoverinfo='text',
        showscale = T
      )
    }
  


  
  res <- hm %>% layout(yaxis = for_yscale, 
                       xaxis = for_xscale, 
                       title = list(text = name_title, x = 0.05, xanchor = "left"),
                       hoverlabel = list(align = "left")
  ) %>% config(displayModeBar = F)
  
  return(res)
  
}

#get_hm(one_course_data)
################################################

#look at full data
look_tab1 <- function(dat){ #, MYNAMES
  datatable(dat,
            plugins = "ellipsis", rownames=F,#  autoWidth = TRUE,
            #colnames = MYNAMES, 
            options = list(dom = 't', ordering=F, pageLength = nrow(dat),autoWidth = TRUE,
                           columnDefs = list(
                             list(targets = 0:2,  className = "dt-head-left", render = JS("$.fn.dataTable.render.ellipsis(35, false )")),
                             #list(targets = 3:6, render = JS("$.fn.dataTable.render.ellipsis(2, false )")),
                             #list(targets = 7, render = JS("$.fn.dataTable.render.ellipsis(8, false )")),
                             #list(targets = 8:9, render = JS("$.fn.dataTable.render.ellipsis(2, false )")),
                             #list(targets = 10, render = JS("$.fn.dataTable.render.ellipsis(6, false )")),
                             #list(targets = 11:12, render = JS("$.fn.dataTable.render.ellipsis(6, false )")),
                             list(targets = 13, render = JS("$.fn.dataTable.render.ellipsis(45, false )"))
                           )
            )
  )
}