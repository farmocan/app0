#функции для использования в shiny app

plotly_hm1 <- function(mydata){
require(plotly)
#mydata <-ag_comb 
#mydata %>% names

#axis label
my_y_week_VECTOR <- mydata$Y_pos %>% unique()
my_x_week_VECTOR <- mydata$X_pos %>% unique()

for_yscale <- list(tickvals = my_y_week_VECTOR, ticktext = my_y_week_VECTOR,  fixedrange=TRUE)#, autorange = "reversed"
for_xscale <- list(tickvals = my_x_week_VECTOR, ticktext = my_x_week_VECTOR,  fixedrange=TRUE)

#plot
hm <- plot_ly(mydata) %>% 
  add_trace(
    type = "heatmap",
    
    x = ~X_pos, y = ~Y_pos, z = rnorm(75, .5, .1), xgap=2, ygap=2,
    colors = "#EEEEE0",
    text = ~info,
    
    hoverinfo='text',
    showscale = F
  )

res <- hm %>% layout(yaxis = for_yscale, xaxis = for_xscale, title = list(
  text = "1) lecture + pos_question", x = 0.1, xanchor = "left")) %>% 
  config(displayModeBar = F)

return(res)
}
#plotly_hm1(data)

plotly_hm2_type <- function(mydata){
  require(plotly)
  #mydata <- data 
  #mydata %>% names
  
  #axis label
  my_y_week_VECTOR <- mydata$Y_pos %>% unique()
  my_x_week_VECTOR <- mydata$X_pos %>% unique()
  
  for_yscale <- list(tickvals = my_y_week_VECTOR, ticktext = my_y_week_VECTOR,  fixedrange=TRUE)#, autorange = "reversed"
  for_xscale <- list(tickvals = my_x_week_VECTOR, ticktext = my_x_week_VECTOR,  fixedrange=TRUE)
  
  #plot
  hm <- plot_ly(mydata) %>% 
    add_trace(
      type = "heatmap",
      
      x = ~X_pos, y = ~Y_pos, z = ~type, xgap=2, ygap=2,
      #colors = "#EEEEE0",
      text = ~info,
      
      hoverinfo='text'
    )
  res <- hm %>% layout(yaxis = for_yscale, xaxis = for_xscale, 
                       title = list(text = "2) HM by type(0-norm, .5-changed text, 1-diff text)",
                                    x = 0.1, xanchor = "left"),
                       legend = list(orientation = "h", x = 0.2)) %>% 
    config(displayModeBar = F)
 
  return(res)
}
#plotly_hm2_type(data)

#


questiondata %>% names
questiondata$info <- paste0("m=",questiondata$m_ord, "|l=",questiondata$l_ord, "|i=",questiondata$i_ord, " pos=", questiondata$aq_ord)
questiondata <- questiondata[,c("info", "question_ext_id", "text", "cnt")]

#MYNAMES <- c("m", "l", "i", "pos", "text", "n", "question_ext_id")
MYNAMES <- c("info", "id", "text", "cnt")
get_datatable <- function(table){
res <- table %>% datatable(., 
                           plugins = "ellipsis", rownames=F, filter = 'top',
                           colnames = MYNAMES,
  options = list(
  autowidth = F,
  
  #columnDefs = list(list(width = '20%', targets = list(4))),
  columnDefs = list(list(width = '5px', targets = 0:1, render = JS("$.fn.dataTable.render.ellipsis(30, false )")),
                    list(width = '1000px', targets = 2),
                    list(width = '10px', targets = 3, render = JS("$.fn.dataTable.render.ellipsis(10, false )"))),
  pageLength = nrow(table),
  lengthMenu = c(7, 14, 28, 36),
  scrollX = TRUE#,
  #fixedColumns = TRUE
)
)
  
  return(res)
}

get_datatable(questiondata)
questiondata$info %>% grepl("m=4|l=0|", .)
