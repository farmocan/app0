rm(list = ls())

require(magrittr)
require(shiny)
require(plotly)
require(DT)
require(htmlwidgets)
#folder <- "D:\\cloud\\app0 heatmap\\"
#setwd(folder)
getwd()

coursera_data <- read.csv2("data/tab1.csv", encoding = "UTF-8")
colnames(coursera_data)[1] <- "cname" #rename!
CNAME <- coursera_data$cname %>% unique()

source("function/hm_coursera_function.R", encoding = "UTF-8")

ui <- shinyUI(
  fluidPage(
    titlePanel(HTML("plotly heat map for Coursera")),
    
    sidebarLayout(
      
      sidebarPanel(
        width = 3,
        h4('Выбор курса'),
        selectInput("cname", "$cname:",
                    choices = CNAME),
        
        selectInput("branch", "$bid:",
                    choices = 0),
        
        selectInput("upload_id", "$course_id:",
                    choices = 0)
        
      ),
      mainPanel(
        tabsetPanel(
          type = "tab",
          tabPanel("data"
                   , br()
                   , DT::dataTableOutput("tab", width = "2500px")
                   ),
          tabPanel("heatmap"
                   ,br()
                   ,plotlyOutput("hm_1")
                   )
          
        )))))
###server

server <- function(input, output, session){
  
  observe({
    x <- input$cname
    # Can use character(0) to remove all choices
    if (is.null(x))
      x <- character(0)
    #to list
    bid_list <- unique(coursera_data$bid[coursera_data$cname == x])
    # Can also set the label and select items
    updateSelectInput(session, "branch",
                      label = paste0("$bid  (n=", length(bid_list), ")"),
                      choices = bid_list,
                      selected = bid_list[1]
    )
  })
  observe({
    x <- input$cname
  ##########upload course
  y <- input$branch
  # Can use character(0) to remove all choices
  if (is.null(y))
    y <- character(0)
  #to list
  course_id_list <- unique(coursera_data$course_id[coursera_data$cname == x & 
                                                     coursera_data$bid == y])
  # Can also set the label and select items
  updateSelectInput(session, "upload_id",
                    label = paste0("$course_id  (n=", length(course_id_list), ")"),
                    choices = course_id_list,
                    selected = course_id_list[1]
  )
  })
  
  subdata <-  reactive({
    coursera_data[coursera_data$cname == input$cname & 
                             coursera_data$bid == input$branch &
                             coursera_data$course_id == input$upload_id,]
    })

  output$tab = DT::renderDataTable({look_tab1(subdata())})#, newnames
  output$hm_1 = renderPlotly(get_hm(subdata()))

}
  
##app
shinyApp(ui = ui, server = server)

